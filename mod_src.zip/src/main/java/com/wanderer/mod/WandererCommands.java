package com.wanderer.mod;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.wanderer.mod.world.RoadNoise;
import com.wanderer.mod.world.TerrainUtil;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /wanderer road : телепортирует к ближайшей грязной дороге. */
@Mod.EventBusSubscriber(modid = WandererMod.MODID)
public class WandererCommands {
    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("wanderer")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("road").executes(c -> findRoad(c.getSource()))));
    }

    private static int findRoad(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        RoadNoise noise = RoadNoise.get(level.getSeed());
        int px = player.blockPosition().getX();
        int pz = player.blockPosition().getZ();
        int[] found = null;
        final int step = 3;
        for (int r = 0; r <= 4000 && found == null; r += step) {
            for (int i = -r; i <= r && found == null; i += step) {
                int[][] pts = {{px + i, pz - r}, {px + i, pz + r}, {px - r, pz + i}, {px + r, pz + i}};
                for (int[] p : pts) {
                    if (noise.isCore(p[0], p[1])
                            && TerrainUtil.isRoadBiome(level.getBiome(new BlockPos(p[0], 64, p[1])))) {
                        found = p;
                        break;
                    }
                }
            }
        }
        if (found == null) {
            src.sendFailure(Component.literal("Дорога не найдена в радиусе 4000 блоков."));
            return 0;
        }
        final int fx = found[0];
        final int fz = found[1];
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, fx, fz);
        player.teleportTo(level, fx + 0.5, y + 1, fz + 0.5, player.getYRot(), player.getXRot());
        src.sendSuccess(() -> Component.literal("Дорога найдена: x=" + fx + ", z=" + fz), false);
        return 1;
    }
}
