package com.wanderer.mod;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.wanderer.mod.world.CampBuilder;
import com.wanderer.mod.world.RoadNoise;
import com.wanderer.mod.world.TerrainUtil;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /wanderer road : к ближайшей дороге. /wanderer camp : к ближайшему лагерю. */
@Mod.EventBusSubscriber(modid = WandererMod.MODID)
public class WandererCommands {
    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("wanderer")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("road").executes(c -> findRoad(c.getSource())))
                .then(Commands.literal("camp").executes(c -> findCamp(c.getSource()))));
    }

    private static int findRoad(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        RoadNoise noise = RoadNoise.get(level.getSeed());
        int px = player.blockPosition().getX();
        int pz = player.blockPosition().getZ();
        int[] found = null;
        final int step = 3;
        for (int r = 0; r <= 4000 && found == null; r += step) {
            for (int i = -r; i <= r && found == null; i += step) {
                int[][] pts = {{px + i, pz - r}, {px + i, pz + r}, {px - r, pz + i}, {px + r, pz + i}};
                for (int[] p : pts) {
                    if (noise.isCore(p[0], p[1])
                            && TerrainUtil.isRoadBiome(level.getBiome(new BlockPos(p[0], 64, p[1])))) {
                        found = p;
                        break;
                    }
                }
            }
        }
        if (found == null) {
            src.sendFailure(Component.literal("Дорога не найдена в радиусе 4000 блоков."));
            return 0;
        }
        final int fx = found[0];
        final int fz = found[1];
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, fx, fz);
        player.teleportTo(level, fx + 0.5, y + 1, fz + 0.5, player.getYRot(), player.getXRot());
        src.sendSuccess(() -> Component.literal("Дорога найдена: x=" + fx + ", z=" + fz), false);
        return 1;
    }

    /** Первая клетка дороги в чанке (тот же порядок обхода, что и при генерации). */
    private static int[] firstRoadCell(ServerLevel level, RoadNoise noise, int cx, int cz) {
        int baseX = cx << 4;
        int baseZ = cz << 4;
        if (noise.mask(baseX + 8, baseZ + 8) < RoadNoise.MASK_MIN - 0.15) return null;
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = baseX + dx;
                int z = baseZ + dz;
                if (noise.isCore(x, z)
                        && TerrainUtil.isRoadBiome(level.getBiome(new BlockPos(x, 64, z)))) {
                    return new int[]{x, z};
                }
            }
        }
        return null;
    }

    private static int findCamp(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        long seed = level.getSeed();
        RoadNoise noise = RoadNoise.get(seed);
        int pcx = player.blockPosition().getX() >> 4;
        int pcz = player.blockPosition().getZ() >> 4;
        int[] cell = null;
        int ccx = 0;
        int ccz = 0;
        for (int r = 0; r <= 300 && cell == null; r++) {
            for (int i = -r; i <= r && cell == null; i++) {
                int[][] chunks = {{pcx + i, pcz - r}, {pcx + i, pcz + r}, {pcx - r, pcz + i}, {pcx + r, pcz + i}};
                for (int[] c : chunks) {
                    if (!CampBuilder.campInChunk(seed, c[0], c[1])) continue;
                    int[] f = firstRoadCell(level, noise, c[0], c[1]);
                    if (f != null) {
                        cell = f;
                        ccx = c[0];
                        ccz = c[1];
                        break;
                    }
                }
            }
        }
        if (cell == null) {
            src.sendFailure(Component.literal("Лагерь не найден рядом (радиус около 4800 блоков)."));
            return 0;
        }
        level.getChunk(ccx, ccz); // генерируем чанк, чтобы лагерь появился
        final int fx = cell[0];
        final int fz = cell[1];
        final int tz = fz + 14; // встаём южнее лагеря и смотрим на север
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, fx, tz);
        player.teleportTo(level, fx + 0.5, y + 1, tz + 0.5, 180.0F, 10.0F);
        src.sendSuccess(() -> Component.literal("Лагерь рядом: центр x=" + fx + ", z=" + fz
                + ". Ты стоишь к югу от него, иди на север."), false);
        return 1;
    }
}
