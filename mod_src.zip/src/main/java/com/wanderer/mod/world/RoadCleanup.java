package com.wanderer.mod.world;

import com.wanderer.mod.WandererMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/**
 * Когда чанк с дорогой загружен (все соседи уже созданы), убирает листву, которая
 * "дорасла" над центром дороги от деревьев соседних чанков.
 */
@Mod.EventBusSubscriber(modid = WandererMod.MODID)
public class RoadCleanup {
    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getChunk() instanceof LevelChunk chunk)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        RoadNoise noise = RoadNoise.get(level.getSeed());
        ChunkPos cp = chunk.getPos();
        int baseX = cp.getMinBlockX();
        int baseZ = cp.getMinBlockZ();
        if (noise.mask(baseX + 8, baseZ + 8) < RoadNoise.MASK_MIN - 0.15) return;

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = baseX + dx;
                int z = baseZ + dz;
                if (!noise.isCore(x, z)) continue;

                int top = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, dx, dz) + 1;
                List<BlockPos> foliage = new ArrayList<>();
                boolean road = false;
                for (int y = top; y > top - 64 && y >= level.getMinBuildHeight(); y--) {
                    p.set(x, y, z);
                    BlockState s = chunk.getBlockState(p);
                    if (s.isAir()) continue;
                    if (s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS)) {
                        foliage.add(p.immutable());
                        continue;
                    }
                    if (s.getCollisionShape(chunk, p).isEmpty()) continue; // трава и т.п.
                    // первый твёрдый блок: это земля, проверяем, что это именно дорога
                    road = s.is(Blocks.COARSE_DIRT) || s.is(Blocks.DIRT)
                            || s.is(Blocks.DIRT_PATH) || s.is(Blocks.MUD);
                    break;
                }
                if (!road || foliage.isEmpty()) continue;
                Holder<Biome> biome = chunk.getNoiseBiome(x >> 2, 16, z >> 2);
                if (!TerrainUtil.isRoadBiome(biome)) continue;
                for (BlockPos lp : foliage) {
                    chunk.setBlockState(lp, Blocks.AIR.defaultBlockState(), false);
                }
            }
        }
    }
}
