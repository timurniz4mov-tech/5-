package com.wanderer.mod.world;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.synth.ImprovedNoise;

/** Шум, по нулевой линии которого идёт дорога (одинаков во всех чанках, поэтому дорога непрерывна). */
public final class RoadNoise {
    /** Порог "маски": чем больше, тем реже дороги в мире. */
    public static final double MASK_MIN = 0.10;

    private static volatile RoadNoise cache;

    final long seed;
    private final ImprovedNoise a, b, mask, width;

    public static RoadNoise get(long seed) {
        RoadNoise c = cache;
        if (c != null && c.seed == seed) return c;
        synchronized (RoadNoise.class) {
            c = cache;
            if (c == null || c.seed != seed) {
                c = new RoadNoise(seed);
                cache = c;
            }
            return c;
        }
    }

    private RoadNoise(long seed) {
        this.seed = seed;
        this.a = new ImprovedNoise(RandomSource.create(seed ^ 0x5DEECE66DL));
        this.b = new ImprovedNoise(RandomSource.create(seed ^ 0x1B873593L));
        this.mask = new ImprovedNoise(RandomSource.create(seed ^ 0x2545F491L));
        this.width = new ImprovedNoise(RandomSource.create(seed ^ 0x7A3C9E15L));
    }

    public double v(double x, double z) {
        return a.noise(x * 0.008, 0.37, z * 0.008) + 0.3 * b.noise(x * 0.025, 1.71, z * 0.025);
    }

    public double mask(double x, double z) {
        return mask.noise(x * 0.003, 2.2, z * 0.003);
    }

    public double width(double x, double z) {
        return width.noise(x * 0.03, 3.3, z * 0.03);
    }

    /**
     * Насколько точка далека от края дороги в блоках: <= 0 значит центр дороги,
     * от 0 до 1.6 значит обочина, Double.MAX_VALUE значит дороги нет.
     */
    public double roadOffset(int x, int z) {
        double m = mask(x, z);
        if (m < MASK_MIN) return Double.MAX_VALUE;
        double taper = Math.min(1.0, (m - MASK_MIN) / 0.10);
        if (taper < 0.08) return Double.MAX_VALUE;
        double v = v(x, z);
        double gx = v(x + 1, z) - v;
        double gz = v(x, z + 1) - v;
        double g = Math.sqrt(gx * gx + gz * gz);
        if (g < 1.0e-5) return Double.MAX_VALUE;
        double dist = Math.abs(v) / g;
        double w = Mth.clamp(width(x, z) * 0.5 + 0.5, 0.0, 1.0);
        double half = (1.1 + 0.9 * w) * taper;
        return dist - half;
    }

    public boolean isCore(int x, int z) {
        return roadOffset(x, z) <= 0.0;
    }
}
