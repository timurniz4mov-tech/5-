package com.wanderer.mod.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.LoomBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * Лагерь: один костёр на булыжнике, рядом бревно и одна палатка 5x5 высотой 3 блока.
 * Весь лагерь помещается внутри одного чанка (клетки 1..14), поэтому деревья соседних чанков,
 * которые генерируются позже, не могут вырасти на палатке.
 */
public final class CampBuilder {
    /** Лагерь бывает в 1 из RARITY чанков, где проходит дорога. Больше число = реже. */
    public static final int RARITY = 10;

    // направление "вдоль палатки" (w) и "поперёк" (u) для поворотов 0..3
    private static final int[] WX = {0, -1, 0, 1};
    private static final int[] WZ = {1, 0, -1, 0};
    private static final int[] UX = {1, 0, -1, 0};
    private static final int[] UZ = {0, 1, 0, -1};
    private static final Direction[] U_DIR = {Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.NORTH};
    // куда смотрит кровать (от ног к голове) = против направления w
    private static final Direction[] BED_FACING = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    /** Стороны палатки относительно костра: запад, восток, север, юг: {dx, dz, поворот}. */
    private static final int[][] SIDES = {{-6, 0, 3}, {6, 0, 1}, {0, -6, 0}, {0, 6, 2}};

    private static final Block[] ALL_BEDS = {
            Blocks.WHITE_BED, Blocks.ORANGE_BED, Blocks.MAGENTA_BED, Blocks.LIGHT_BLUE_BED,
            Blocks.YELLOW_BED, Blocks.LIME_BED, Blocks.PINK_BED, Blocks.GRAY_BED,
            Blocks.LIGHT_GRAY_BED, Blocks.CYAN_BED, Blocks.PURPLE_BED, Blocks.BLUE_BED,
            Blocks.BROWN_BED, Blocks.GREEN_BED, Blocks.RED_BED, Blocks.BLACK_BED};

    private CampBuilder() {}

    private static long mix(long seed, int cx, int cz, long salt) {
        long h = seed ^ ((long) cx * 0x9E3779B97F4A7C15L) ^ ((long) cz * 0xC2B2AE3D27D4EB4FL) ^ salt;
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return h;
    }

    /** Одинаково для генерации и для команды /wanderer camp. */
    public static boolean campInChunk(long seed, int cx, int cz) {
        return Math.floorMod(mix(seed, cx, cz, 0L), (long) RARITY) == 0L;
    }

    /** На какой стороне от костра стоит палатка (0 запад, 1 восток, 2 север, 3 юг). */
    public static int campSide(long seed, int cx, int cz) {
        return (int) Math.floorMod(mix(seed, cx, cz, 0x5851F42D4C957F2DL), 4L);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Мировые x, z костра: ближайшая к дороге точка, при которой весь лагерь остаётся внутри чанка. */
    public static int[] anchor(int side, int chunkX, int chunkZ, int roadX, int roadZ) {
        int lx = roadX - (chunkX << 4);
        int lz = roadZ - (chunkZ << 4);
        int fx;
        int fz;
        switch (side) {
            case 0: fx = clamp(lx, 9, 10); fz = clamp(lz, 5, 10); break; // палатка на западе
            case 1: fx = clamp(lx, 5, 6);  fz = clamp(lz, 5, 10); break; // на востоке
            case 2: fx = clamp(lx, 5, 10); fz = clamp(lz, 9, 10); break; // на севере
            default: fx = clamp(lx, 5, 10); fz = clamp(lz, 5, 6); break; // на юге
        }
        return new int[]{(chunkX << 4) + fx, (chunkZ << 4) + fz};
    }

    /** Строит лагерь, если местность не слишком крутая. */
    public static boolean tryBuild(WorldGenLevel level, int fx, int fz, int side, RandomSource random,
                                   int clipMinX, int clipMaxX, int clipMinZ, int clipMaxZ) {
        int y0 = TerrainUtil.groundY(level, fx, fz);
        if (y0 == TerrainUtil.NONE) return false;
        int[] s = SIDES[side];
        int[][] samples = {{0, 0}, {s[0], s[1]}, {s[0] + Integer.signum(s[0]) * 2, s[1] + Integer.signum(s[1]) * 2},
                {3, 0}, {-3, 0}, {0, 3}, {0, -3}};
        int min = y0, max = y0;
        for (int[] o : samples) {
            int gy = TerrainUtil.groundY(level, fx + o[0], fz + o[1]);
            if (gy == TerrainUtil.NONE) continue;
            min = Math.min(min, gy);
            max = Math.max(max, gy);
        }
        if (max - min > 4) return false;
        build(level, fx, y0, fz, side, random, clipMinX, clipMaxX, clipMinZ, clipMaxZ);
        return true;
    }

    public static void build(WorldGenLevel level, int fx, int y0, int fz, int side, RandomSource random,
                             int clipMinX, int clipMaxX, int clipMinZ, int clipMaxZ) {
        int[] s = SIDES[side];
        int tcx = fx + s[0];
        int tcz = fz + s[1];
        boolean tentOnX = s[0] != 0;
        int halfX = tentOnX ? 2 : 3;
        int halfZ = tentOnX ? 3 : 2;

        // 1. убираем все деревья вокруг лагеря (в пределах чанка), чтобы рядом ничего не мешало
        int bufMinX = Math.max(clipMinX, Math.min(fx - 4, tcx - halfX) - 3);
        int bufMaxX = Math.min(clipMaxX, Math.max(fx + 4, tcx + halfX) + 3);
        int bufMinZ = Math.max(clipMinZ, Math.min(fz - 4, tcz - halfZ) - 3);
        int bufMaxZ = Math.min(clipMaxZ, Math.max(fz + 4, tcz + halfZ) + 3);
        for (int x = bufMinX; x <= bufMaxX; x++) {
            for (int z = bufMinZ; z <= bufMaxZ; z++) {
                int gy = TerrainUtil.groundY(level, x, z);
                if (gy != TerrainUtil.NONE) {
                    TerrainUtil.removeTreeAbove(level, x, gy, z, 40);
                }
            }
        }

        // 2. выравниваем площадку: пятно земли у костра и площадка под палатку
        for (int x = fx - 9; x <= fx + 9; x++) {
            for (int z = fz - 9; z <= fz + 9; z++) {
                if (x < clipMinX || x > clipMaxX || z < clipMinZ || z > clipMaxZ) continue;
                int dx = x - fx;
                int dz = z - fz;
                int d2 = dx * dx + dz * dz;
                boolean patch = d2 <= 16;
                boolean tentArea = Math.abs(x - tcx) <= halfX && Math.abs(z - tcz) <= halfZ;
                if (!patch && !tentArea) continue;
                int gy = TerrainUtil.groundY(level, x, z);
                if (gy == TerrainUtil.NONE) continue;

                for (int y = y0 + 1; y <= y0 + 10; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!level.getBlockState(p).isAir()) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
                if (gy < y0) {
                    for (int y = gy + 1; y < y0; y++) {
                        level.setBlock(new BlockPos(x, y, z), Blocks.DIRT.defaultBlockState(), 2);
                    }
                }
                if (patch && (d2 <= 5 || random.nextFloat() < 0.7F)) {
                    level.setBlock(new BlockPos(x, y0, z), floor(random), 2);
                } else if (gy != y0) {
                    level.setBlock(new BlockPos(x, y0, z), Blocks.GRASS_BLOCK.defaultBlockState(), 2);
                }
            }
        }

        int b = y0 + 1; // уровень, на котором стоят предметы

        // 3. один костёр, под ним булыжник
        level.setBlock(new BlockPos(fx, y0, fz), Blocks.COBBLESTONE.defaultBlockState(), 2);
        level.setBlock(new BlockPos(fx, b, fz),
                Blocks.CAMPFIRE.defaultBlockState().setValue(CampfireBlock.LIT, true), 2);

        // 4. одна палатка, вход смотрит на костёр
        tent(level, tcx, b, tcz, s[2], random);

        // 5. бревно лежит рядом с костром сбоку от палатки (через один блок от костра)
        int sign = random.nextBoolean() ? 1 : -1;
        int lx = tentOnX ? fx : fx + 2 * sign;
        int lz = tentOnX ? fz + 2 * sign : fz;
        Direction.Axis axis = tentOnX ? Direction.Axis.X : Direction.Axis.Z;
        BlockState log = Blocks.SPRUCE_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, axis);
        for (int k = -1; k <= 1; k++) {
            put(level, lx + (axis == Direction.Axis.X ? k : 0), b, lz + (axis == Direction.Axis.Z ? k : 0), log);
        }
    }

    private static BlockState floor(RandomSource r) {
        float f = r.nextFloat();
        if (f < 0.35F) return Blocks.COARSE_DIRT.defaultBlockState();
        if (f < 0.65F) return Blocks.DIRT.defaultBlockState();
        return Blocks.DIRT_PATH.defaultBlockState();
    }

    /**
     * Палатка 5 блоков в ширину и в длину, высота 3 блока.
     * Вдоль: ступенька дуба, 3 блока мха, ступенька дуба (по бокам торцы-арки).
     * Поперёк: у стен низко (1 блок), дальше 2, по центру 3 блока.
     * Торец: блок дуба сверху, плитка дуба под ним (над входом), ступеньки по бокам.
     * Внутри мшистый пол, слева верстак и кровать, справа кровать и ткацкий станок.
     */
    private static void tent(WorldGenLevel level, int tx, int b, int tz, int r, RandomSource random) {
        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState moss = Blocks.MOSS_BLOCK.defaultBlockState();
        Direction toCenterFromLeft = U_DIR[r];
        Direction toCenterFromRight = U_DIR[r].getOpposite();
        BlockState stairLeft = Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, toCenterFromLeft);
        BlockState stairRight = Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, toCenterFromRight);
        BlockState slabTop = Blocks.OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);

        for (int w = -2; w <= 2; w++) {
            for (int u = -2; u <= 2; u++) {
                int au = Math.abs(u);
                int x = tx + u * UX[r] + w * WX[r];
                int z = tz + u * UZ[r] + w * WZ[r];
                int roofY = 2 - au; // верхний блок столбца: 0..2 (высота 3)

                if (Math.abs(w) == 2) {                          // торцы
                    boolean front = (w == 2);
                    BlockState stair = (u < 0) ? stairLeft : stairRight;
                    if (au == 2) {
                        put(level, x, b, z, stair);
                    } else if (au == 1) {
                        put(level, x, b, z, planks);
                        put(level, x, b + 1, z, stair);
                    } else {
                        if (front) {
                            put(level, x, b + 1, z, slabTop);     // плитка над входом
                        } else {
                            put(level, x, b, z, planks);
                            put(level, x, b + 1, z, planks);
                        }
                        put(level, x, b + 2, z, planks);          // блок дуба сверху
                    }
                } else {                                         // середина: мох ступенями
                    put(level, x, b + roofY, z, moss);
                }
                if (Math.abs(w) <= 1 && au <= 1) {
                    put(level, x, b - 1, z, moss);               // пол внутри
                }
            }
        }
        Direction facing = BED_FACING[r];
        // левая сторона (u=-1): верстак у задней стенки, кровать (голова w=0, ноги w=+1)
        put(level, tx - UX[r] - WX[r], b, tz - UZ[r] - WZ[r], Blocks.CRAFTING_TABLE.defaultBlockState());
        bed(level, tx - UX[r] + WX[r], b, tz - UZ[r] + WZ[r], facing, randomBed(random));
        // правая сторона (u=+1): кровать (голова w=-1, ноги w=0), ткацкий станок у входа
        bed(level, tx + UX[r], b, tz + UZ[r], facing, randomBed(random));
        put(level, tx + UX[r] + WX[r], b, tz + UZ[r] + WZ[r],
                Blocks.LOOM.defaultBlockState().setValue(LoomBlock.FACING, U_DIR[r].getOpposite()));
    }

    /** Цвет кровати: 1/3 белая, 1/3 зелёная, 1/3 любого цвета. */
    private static BlockState randomBed(RandomSource random) {
        float f = random.nextFloat();
        if (f < 1.0F / 3.0F) return Blocks.WHITE_BED.defaultBlockState();
        if (f < 2.0F / 3.0F) return Blocks.GREEN_BED.defaultBlockState();
        return ALL_BEDS[random.nextInt(ALL_BEDS.length)].defaultBlockState();
    }

    private static void bed(WorldGenLevel level, int x, int y, int z, Direction facing, BlockState bed) {
        BlockPos foot = new BlockPos(x, y, z);
        BlockState bs = bed.setValue(BedBlock.FACING, facing);
        level.setBlock(foot, bs.setValue(BedBlock.PART, BedPart.FOOT), 2);
        level.setBlock(foot.relative(facing), bs.setValue(BedBlock.PART, BedPart.HEAD), 2);
    }

    private static void put(WorldGenLevel level, int x, int y, int z, BlockState s) {
        level.setBlock(new BlockPos(x, y, z), s, 2);
    }
}
