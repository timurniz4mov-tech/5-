package com.wanderer.mod.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.SlabType;

/** Лагерь: один костёр на булыжнике, рядом бревно и одна палатка 5x5 высотой 3 блока. */
public final class CampBuilder {
    /** Лагерь бывает в 1 из RARITY чанков, где проходит дорога. Больше число = реже. */
    public static final int RARITY = 10;

    // направление "вдоль палатки" (w) и "поперёк" (u) для поворотов 0..3
    private static final int[] WX = {0, -1, 0, 1};
    private static final int[] WZ = {1, 0, -1, 0};
    private static final int[] UX = {1, 0, -1, 0};
    private static final int[] UZ = {0, 1, 0, -1};
    private static final Direction[] U_DIR = {Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.NORTH};
    // куда смотрит кровать (от ног к голове) = против направления w
    private static final Direction[] BED_FACING = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    private CampBuilder() {}

    /** Одинаково для генерации и для команды /wanderer camp. */
    public static boolean campInChunk(long seed, int cx, int cz) {
        long h = seed ^ ((long) cx * 0x9E3779B97F4A7C15L) ^ ((long) cz * 0xC2B2AE3D27D4EB4FL);
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return Math.floorMod(h, (long) RARITY) == 0L;
    }

    /** Строит лагерь, если местность не слишком крутая. */
    public static boolean tryBuild(WorldGenLevel level, BlockPos c, RandomSource random) {
        int min = c.getY(), max = c.getY();
        int[] offs = {-6, 0, 6};
        for (int ox : offs) {
            for (int oz : offs) {
                int gy = TerrainUtil.groundY(level, c.getX() + ox, c.getZ() + oz);
                if (gy == TerrainUtil.NONE) continue;
                min = Math.min(min, gy);
                max = Math.max(max, gy);
            }
        }
        if (max - min > 8) return false;
        build(level, c.getX(), c.getY(), c.getZ(), random);
        return true;
    }

    public static void build(WorldGenLevel level, int cx, int y0, int cz, RandomSource random) {
        // 1. выравниваем площадку, очищаем от деревьев и травы, делаем неровное пятно земли
        for (int dx = -10; dx <= 10; dx++) {
            for (int dz = -10; dz <= 10; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 > 100) continue;
                int x = cx + dx, z = cz + dz;
                int gy = TerrainUtil.groundY(level, x, z);
                if (gy == TerrainUtil.NONE) continue;

                for (int y = y0 + 1; y <= y0 + 10; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!level.getBlockState(p).isAir()) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
                if (gy < y0) {
                    for (int y = gy + 1; y < y0; y++) {
                        level.setBlock(new BlockPos(x, y, z), Blocks.DIRT.defaultBlockState(), 2);
                    }
                }
                if (d2 <= 20 && (d2 <= 6 || random.nextFloat() < 0.7F)) {
                    level.setBlock(new BlockPos(x, y0, z), floor(random), 2);
                } else if (gy != y0) {
                    level.setBlock(new BlockPos(x, y0, z), Blocks.COARSE_DIRT.defaultBlockState(), 2);
                }
            }
        }

        int b = y0 + 1; // уровень, на котором стоят предметы

        // 2. один костёр, под ним булыжник
        level.setBlock(new BlockPos(cx, y0, cz), Blocks.COBBLESTONE.defaultBlockState(), 2);
        level.setBlock(new BlockPos(cx, b, cz),
                Blocks.CAMPFIRE.defaultBlockState().setValue(CampfireBlock.LIT, true), 2);

        // 3. одна палатка на случайной стороне, вход смотрит на костёр
        int[][] sides = {{-6, 0, 3}, {6, 0, 1}, {0, -6, 0}, {0, 6, 2}}; // запад, восток, север, юг
        int s = random.nextInt(4);
        tent(level, cx + sides[s][0], b, cz + sides[s][1], sides[s][2]);

        // 4. бревно лежит рядом с костром сбоку от палатки (через один блок от костра)
        boolean tentOnX = sides[s][0] != 0;       // палатка к западу/востоку => бревно к северу/югу
        int sign = random.nextBoolean() ? 1 : -1;
        int lx = tentOnX ? cx : cx + 2 * sign;
        int lz = tentOnX ? cz + 2 * sign : cz;
        Direction.Axis axis = tentOnX ? Direction.Axis.X : Direction.Axis.Z;
        BlockState log = Blocks.SPRUCE_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, axis);
        for (int k = -1; k <= 1; k++) {
            put(level, lx + (axis == Direction.Axis.X ? k : 0), b, lz + (axis == Direction.Axis.Z ? k : 0), log);
        }
    }

    private static BlockState floor(RandomSource r) {
        float f = r.nextFloat();
        if (f < 0.35F) return Blocks.COARSE_DIRT.defaultBlockState();
        if (f < 0.65F) return Blocks.DIRT.defaultBlockState();
        return Blocks.DIRT_PATH.defaultBlockState();
    }

    /**
     * Палатка 5 блоков в ширину и в длину, высота 3 блока.
     * Вдоль: ступенька дуба, 3 блока мха, ступенька дуба (по бокам торцы-арки).
     * Поперёк: у стен низко (1 блок), дальше 2, по центру 3 блока.
     * Торец: блок дуба сверху, плитка дуба под ним (над входом), ступеньки по бокам.
     * Внутри мшистый пол и две кровати.
     */
    private static void tent(WorldGenLevel level, int tx, int b, int tz, int r) {
        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState moss = Blocks.MOSS_BLOCK.defaultBlockState();
        Direction toCenterFromLeft = U_DIR[r];              // с левой стороны (u<0) центр в сторону +u
        Direction toCenterFromRight = U_DIR[r].getOpposite();
        BlockState stairLeft = Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, toCenterFromLeft);
        BlockState stairRight = Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, toCenterFromRight);
        BlockState slabTop = Blocks.OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.TOP);

        for (int w = -2; w <= 2; w++) {
            for (int u = -2; u <= 2; u++) {
                int au = Math.abs(u);
                int x = tx + u * UX[r] + w * WX[r];
                int z = tz + u * UZ[r] + w * WZ[r];
                int roofY = 2 - au; // верхний блок столбца: 0..2 (высота 3)

                if (Math.abs(w) == 2) {                          // торцы
                    boolean front = (w == 2);
                    BlockState stair = (u < 0) ? stairLeft : stairRight;
                    if (au == 2) {
                        put(level, x, b, z, stair);               // нижние ступеньки
                    } else if (au == 1) {
                        put(level, x, b, z, planks);
                        put(level, x, b + 1, z, stair);           // ступеньки выше
                    } else {                                      // центр
                        if (front) {
                            put(level, x, b + 1, z, slabTop);     // плитка над входом
                        } else {
                            put(level, x, b, z, planks);
                            put(level, x, b + 1, z, planks);
                        }
                        put(level, x, b + 2, z, planks);          // блок дуба сверху
                    }
                } else {                                         // середина: мох ступенями
                    put(level, x, b + roofY, z, moss);
                }
                if (Math.abs(w) <= 1 && au <= 1) {
                    put(level, x, b - 1, z, moss);               // пол внутри
                }
            }
        }
        // две кровати у стен: голова к задней стенке
        Direction facing = BED_FACING[r];
        bed(level, tx - UX[r], b, tz - UZ[r], facing, Blocks.WHITE_BED.defaultBlockState());
        bed(level, tx + UX[r], b, tz + UZ[r], facing, Blocks.WHITE_BED.defaultBlockState());
    }

    private static void bed(WorldGenLevel level, int x, int y, int z, Direction facing, BlockState bed) {
        BlockPos foot = new BlockPos(x, y, z);
        BlockState bs = bed.setValue(BedBlock.FACING, facing);
        level.setBlock(foot, bs.setValue(BedBlock.PART, BedPart.FOOT), 2);
        level.setBlock(foot.relative(facing), bs.setValue(BedBlock.PART, BedPart.HEAD), 2);
    }

    private static void put(WorldGenLevel level, int x, int y, int z, BlockState s) {
        level.setBlock(new BlockPos(x, y, z), s, 2);
    }
}
