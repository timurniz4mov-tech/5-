package com.wanderer.mod.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public final class TerrainUtil {
    public static final int NONE = Integer.MIN_VALUE;

    private TerrainUtil() {}

    /** Высота земли (блок почвы) в колонке или NONE, если там вода/постройка/камень. */
    public static int groundY(WorldGenLevel level, int x, int z) {
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
        int bottom = Math.max(level.getMinBuildHeight(), top - 32);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = top; y >= bottom; y--) {
            p.set(x, y, z);
            BlockState s = level.getBlockState(p);
            if (!s.getFluidState().isEmpty()) return NONE;
            if (s.is(BlockTags.DIRT)) return y;
            if (s.isAir() || s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS)
                    || s.getCollisionShape(level, p).isEmpty()) {
                continue;
            }
            return NONE;
        }
        return NONE;
    }

    public static boolean isRoadBiome(Holder<Biome> b) {
        return b.is(BiomeTags.IS_FOREST) || b.is(BiomeTags.IS_TAIGA)
                || b.is(Biomes.PLAINS) || b.is(Biomes.SUNFLOWER_PLAINS) || b.is(Biomes.MEADOW);
    }

    /** Убирает траву/цветы/папоротники над дорогой. */
    public static void clearPlantsAbove(WorldGenLevel level, int x, int groundY, int z) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = groundY + 1; y <= groundY + 3; y++) {
            p.set(x, y, z);
            BlockState s = level.getBlockState(p);
            if (s.isAir() || !s.getFluidState().isEmpty()) break;
            if (s.getCollisionShape(level, p).isEmpty()) {
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
            } else {
                break;
            }
        }
    }

    /**
     * Убирает дерево над клеткой: стволы целиком вместе с листвой, которая на них держалась
     * (чтобы не оставалось парящих кусков листвы), и любую листву в этой колонке до высоты leafMaxHeight.
     */
    public static void removeTreeAbove(WorldGenLevel level, int x, int groundY, int z, int leafMaxHeight) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        java.util.List<BlockPos> removedLogs = new java.util.ArrayList<>();
        int top = Math.min(level.getMaxBuildHeight() - 1, groundY + 40);
        for (int y = groundY + 1; y <= top; y++) {
            p.set(x, y, z);
            BlockState s = level.getBlockState(p);
            if (s.isAir()) continue;
            if (s.is(BlockTags.LOGS)) {
                removedLogs.add(p.immutable());
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
            } else if (s.is(BlockTags.LEAVES)) {
                if (y <= groundY + leafMaxHeight) {
                    level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                }
            } else if (s.getCollisionShape(level, p).isEmpty()) {
                continue; // трава, лозы и т.п.
            } else {
                break;
            }
        }
        for (BlockPos log : removedLogs) {
            removeSupportedLeaves(level, log);
        }
    }

    /** Убирает листву, державшуюся на удалённом стволе (по значению DISTANCE у листьев). */
    private static void removeSupportedLeaves(WorldGenLevel level, BlockPos origin) {
        java.util.ArrayDeque<BlockPos> positions = new java.util.ArrayDeque<>();
        java.util.ArrayDeque<Integer> distances = new java.util.ArrayDeque<>();
        positions.add(origin);
        distances.add(0);
        int guard = 0;
        while (!positions.isEmpty() && guard++ < 800) {
            BlockPos cur = positions.poll();
            int d = distances.poll();
            if (d >= 7) continue;
            for (Direction dir : Direction.values()) {
                BlockPos n = cur.relative(dir);
                BlockState ns = level.getBlockState(n);
                if (ns.getBlock() instanceof LeavesBlock && ns.hasProperty(LeavesBlock.DISTANCE)
                        && ns.getValue(LeavesBlock.DISTANCE) == d + 1) {
                    level.setBlock(n, Blocks.AIR.defaultBlockState(), 2);
                    positions.add(n);
                    distances.add(d + 1);
                }
            }
        }
    }
}
