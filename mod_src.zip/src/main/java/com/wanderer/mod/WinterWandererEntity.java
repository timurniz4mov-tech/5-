package com.wanderer.mod;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

/**
 * Зимний путник: тот же ум, что у обычного (кровать, обход врагов, бой/бегство), но живёт в снежных биомах,
 * не мёрзнет и ходит по рыхлому снегу без кожаных сапог (тег powder_snow_walkable_mobs в датапаке).
 */
public class WinterWandererEntity extends WandererEntity {
    public WinterWandererEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Override
    public boolean isWinter() {
        return true;
    }

    @Override
    public boolean canFreeze() {
        return false;
    }
}
