package com.wanderer.mod;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;

/** Модель игрока с боевой стойкой (руки подняты, когда путник нападает) и приседанием. */
public class WandererModel extends PlayerModel<WandererEntity> {
    public WandererModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void prepareMobModel(WandererEntity entity, float limbSwing, float limbSwingAmount, float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        this.crouching = entity.isCrouching();
    }

    @Override
    public void setupAnim(WandererEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (entity.isAggressive() && !entity.isSleeping()) {
            // боевая стойка: правая рука с оружием поднята вперёд, замах при ударе накладывается сверху
            this.rightArm.xRot -= 0.9F;
            this.rightArm.yRot -= 0.1F;
            this.leftArm.xRot -= 0.35F;
            this.rightSleeve.copyFrom(this.rightArm);
            this.leftSleeve.copyFrom(this.leftArm);
        }
    }
}
