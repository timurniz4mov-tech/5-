package com.wanderer.mod;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;

/** Модель игрока: поза руки с предметом и анимация удара как у игрока, приседание. */
public class WandererModel extends PlayerModel<WandererEntity> {
    public WandererModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    @Override
    public void prepareMobModel(WandererEntity entity, float limbSwing, float limbSwingAmount, float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        this.crouching = entity.isCrouching();
        // как у игрока: если в руке предмет, рука слегка выставлена вперёд
        this.rightArmPose = entity.getMainHandItem().isEmpty()
                ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM;
        this.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        // замах руки как у игрока при ударе
        float swing = entity.getSwingProgress(partialTick);
        if (swing > 0.0F) {
            this.attackTime = swing;
        }
    }
}
