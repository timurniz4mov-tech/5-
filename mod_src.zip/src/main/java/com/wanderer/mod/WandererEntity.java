package com.wanderer.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Witch;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.level.pathfinder.PathFinder;
import net.minecraft.world.level.pathfinder.WalkNodeEvaluator;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Путник. При появлении: 5% посох путника, 11% обычная палка, 84% без оружия.
 * Ударили: без посоха 35% драться и 65% убегать, с посохом 45% драться и 55% убегать.
 * Ночью идёт спать на кровать (только если до неё есть дорога). Подбирает посох путника и броню
 * в радиусе 15 блоков. В узких местах (1.5 блока) приседает. От враждебных мобов спокойно уходит.
 */
public class WandererEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(WandererEntity.class, EntityDataSerializers.INT); // 0 пусто, 1 палка, 2 посох
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(WandererEntity.class, EntityDataSerializers.INT);

    private static final EntityDimensions STAND_DIMS = EntityDimensions.scalable(0.6F, 1.8F);
    private static final EntityDimensions CROUCH_DIMS = EntityDimensions.scalable(0.6F, 1.5F);
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    /** От кого убегаем и сколько ещё тиков. */
    private LivingEntity fleeFrom;
    private int fleeTicks;

    /** Решение "драться или убегать" запоминаем на 30 секунд для каждого обидчика. */
    private UUID decidedAttacker;
    private long decidedTime;
    private boolean decidedFight;

    /** Принудительное приседание (если путник застрял в проходе) и прямое движение без пути. */
    private int forceCrouch;
    private int directMoveTicks;
    private int stuckTicks;

    /** Только на клиенте: сколько тиков ещё идёт анимация удара. */
    private int clientSwing;

    /** Предметы, до которых не дойти (временно пропускаем). */
    private final Map<UUID, Long> badItems = new HashMap<>();

    /** Кровати, до которых не дойти (временно пропускаем). */
    private final Map<BlockPos, Long> badBeds = new HashMap<>();

    public WandererEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    /** 20 хп, как у игрока. */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D);
    }

    /** Навигация, которая считает проход под верхней плиткой (высота 1.5) возможным: путник там присядет. */
    @Override
    protected PathNavigation createNavigation(Level level) {
        return new GroundPathNavigation(this, level) {
            {
                // больше клеток на поиск пути: чтобы обойти палатку и найти вход к кровати
                this.setMaxVisitedNodesMultiplier(4.0F);
            }

            @Override
            protected PathFinder createPathFinder(int maxVisitedNodes) {
                this.nodeEvaluator = new CrouchNodeEvaluator();
                this.nodeEvaluator.setCanPassDoors(true);
                return new PathFinder(this.nodeEvaluator, maxVisitedNodes);
            }
        };
    }

    static class CrouchNodeEvaluator extends WalkNodeEvaluator {
        @Override
        public BlockPathTypes getBlockPathType(BlockGetter level, int x, int y, int z) {
            BlockPathTypes type = super.getBlockPathType(level, x, y, z);
            if (type == BlockPathTypes.BLOCKED) {
                BlockState s = level.getBlockState(new BlockPos(x, y, z));
                if (s.getBlock() instanceof SlabBlock && s.getValue(SlabBlock.TYPE) == SlabType.TOP) {
                    return BlockPathTypes.OPEN;
                }
            }
            return type;
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new FleeAttackerGoal(this));
        this.goalSelector.addGoal(1, new SleepInBedGoal(this));
        this.goalSelector.addGoal(2, new FightGoal(this));
        this.goalSelector.addGoal(2, new PickUpStaffGoal(this));
        this.goalSelector.addGoal(2, new PickUpArmorGoal(this));
        // от враждебных мобов спокойно уходит шагом (не бежит)
        this.goalSelector.addGoal(3, new AvoidEntityGoal<>(this, Monster.class, 9.0F, 1.0D, 1.0D,
                m -> !(m instanceof NeutralMob)));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
        this.entityData.define(SKIN, 0);
    }

    public int getVariant() {
        return this.entityData.get(VARIANT);
    }

    public void setVariant(int variant) {
        this.entityData.set(VARIANT, variant);
    }

    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, skin);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (pose == Pose.CROUCHING) {
            return CROUCH_DIMS;
        }
        return super.getDimensions(pose);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        tag.putInt("Skin", getSkin());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        setSkin(tag.getInt("Skin"));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        setSkin(this.random.nextInt(2)); // 50% / 50% один из двух скинов

        float r = this.random.nextFloat();
        if (r < 0.05F) {                       // 5% посох путника
            setVariant(2);
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(WandererMod.WANDERER_STAFF.get()));
        } else if (r < 0.16F) {                // 11% обычная палка
            setVariant(1);
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STICK));
        } else {                               // 84% без оружия
            setVariant(0);
        }
        return data;
    }

    /** Зимний путник переопределяет это. */
    public boolean isWinter() {
        return false;
    }

    private boolean hasStaff() {
        return this.getItemBySlot(EquipmentSlot.MAINHAND).is(WandererMod.WANDERER_STAFF.get());
    }

    // ------------------------------------------------------------------ сон / поведение

    private static boolean isNightTime(Level level) {
        return level.getDayTime() % 24000L >= 12600L;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.isSleeping();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            if (this.clientSwing > 0) {
                this.clientSwing--;
            }
        } else {
            serverTick();
        }
    }

    /** Сервер: показывает всем клиентам замах руки (как у игрока). */
    void triggerAttackAnim() {
        this.level().broadcastEntityEvent(this, (byte) 4);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 4) {
            this.clientSwing = 6;
            this.swing(InteractionHand.MAIN_HAND);
        } else {
            super.handleEntityEvent(id);
        }
    }

    /** 0..1: как далеко зашёл замах (для модели). */
    public float getSwingProgress(float partialTick) {
        if (this.clientSwing <= 0) return 0.0F;
        return Mth.clamp(1.0F - ((float) this.clientSwing - partialTick) / 6.0F, 0.0F, 1.0F);
    }

    private void serverTick() {
        // утром просыпаемся
        if (this.isSleeping() && !isNightTime(this.level())) {
            this.stopSleeping();
        }
        // застрял на пути (например, упёрся в низкий проход): через полсекунды принудительно приседаем
        if (!this.isSleeping() && !this.getNavigation().isDone()) {
            double mdx = this.getX() - this.xo;
            double mdz = this.getZ() - this.zo;
            if (mdx * mdx + mdz * mdz < 1.0E-5D) {
                if (++this.stuckTicks > 12) {
                    this.forceCrouch = 40;
                    this.stuckTicks = 0;
                }
            } else {
                this.stuckTicks = 0;
            }
        } else {
            this.stuckTicks = 0;
        }
        if (this.forceCrouch > 0) this.forceCrouch--;
        if (this.directMoveTicks > 0) this.directMoveTicks--;
        // приседание в узких местах
        if (!this.isSleeping() && this.tickCount % 2 == 0) {
            updateCrouch();
        }
        // таймер бегства
        if (this.fleeTicks > 0) {
            this.fleeTicks--;
            if (this.fleeTicks == 0 || this.fleeFrom == null || !this.fleeFrom.isAlive()) {
                this.fleeFrom = null;
                this.fleeTicks = 0;
            }
        }
        // бой заканчивается, если цель умерла или убежала далеко
        LivingEntity t = this.getTarget();
        if (t != null && (!t.isAlive() || this.distanceToSqr(t) > 32.0D * 32.0D
                || (t instanceof Player p && p.isSpectator()))) {
            this.setTarget(null);
        }
        // враждебные мобы рядом нападают на путника
        if (this.tickCount % 20 == 0) {
            for (Monster m : this.level().getEntitiesOfClass(Monster.class,
                    this.getBoundingBox().inflate(12.0D, 4.0D, 12.0D))) {
                if (m instanceof NeutralMob) continue;
                if (m.getTarget() == null && m.hasLineOfSight(this)) {
                    m.setTarget(this);
                }
                // ведьма кидает зелья: яд не показывает, кто ударил, поэтому реагируем на саму ведьму
                if (m instanceof Witch && m.getTarget() == this && this.distanceToSqr(m) < 16.0D * 16.0D) {
                    reactToAttacker(m);
                }
            }
        }
    }

    // ------------------------------------------------------------------ приседание

    private boolean heightBlockedAt(Vec3 pos) {
        return !this.level().noCollision(this, STAND_DIMS.makeBoundingBox(pos))
                && this.level().noCollision(this, CROUCH_DIMS.makeBoundingBox(pos));
    }

    /** Приседает, если стоя не проходит (потолок ниже 1.8), но сидя проходит (1.5). */
    private void updateCrouch() {
        boolean blocked = heightBlockedAt(this.position());
        if (!blocked && this.forceCrouch > 0
                && this.level().noCollision(this, CROUCH_DIMS.makeBoundingBox(this.position()))) {
            blocked = true; // застряли: принудительно садимся
        }
        if (!blocked) {
            // куда путник идёт: к следующей точке пути и туда, куда повёрнуто тело
            // (скорость и управление движением тут не годятся: упёршись в проход, путник стоит на месте)
            List<Vec3> dirs = new ArrayList<>(2);
            Path path = this.getNavigation().getPath();
            if (path != null && !path.isDone()) {
                Vec3 next = path.getNextEntityPos(this);
                double dx = next.x - this.getX();
                double dz = next.z - this.getZ();
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len > 0.05D) {
                    dirs.add(new Vec3(dx / len, 0.0D, dz / len));
                }
            }
            if (!this.getNavigation().isDone() || this.directMoveTicks > 0) {
                float yaw = this.yBodyRot * ((float) Math.PI / 180F);
                dirs.add(new Vec3(-Mth.sin(yaw), 0.0D, Mth.cos(yaw)));
            }
            for (Vec3 d : dirs) {
                if (heightBlockedAt(this.position().add(d.scale(0.45D)))
                        || heightBlockedAt(this.position().add(d.scale(0.9D)))) {
                    blocked = true;
                    break;
                }
            }
        }
        boolean crouched = this.getPose() == Pose.CROUCHING;
        if (blocked && !crouched) {
            this.setPose(Pose.CROUCHING);
        } else if (!blocked && crouched) {
            this.setPose(Pose.STANDING);
        }
    }

    // ------------------------------------------------------------------ получение урона

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && !this.level().isClientSide) {
            if (this.isSleeping()) {
                this.stopSleeping();
            }
            Entity attacker = source.getEntity();
            if (attacker instanceof LivingEntity le && le != this && !(le instanceof WandererEntity)) {
                reactToAttacker(le);
            }
        }
        return result;
    }

    /**
     * Без посоха: 35% драться до конца, 65% убегать.
     * С посохом путника: 45% драться, 55% убегать.
     * Решение держится 30 секунд для одного и того же обидчика.
     */
    private void reactToAttacker(LivingEntity attacker) {
        long now = this.level().getGameTime();
        UUID id = attacker.getUUID();
        if (!(id.equals(this.decidedAttacker) && now - this.decidedTime < 600L)) {
            this.decidedAttacker = id;
            float fightChance = hasStaff() ? 0.45F : 0.35F;
            this.decidedFight = this.random.nextFloat() < fightChance;
        }
        this.decidedTime = now;
        if (this.decidedFight) {
            this.fleeFrom = null;
            this.fleeTicks = 0;
            this.setTarget(attacker);
        } else {
            this.setTarget(null);
            this.fleeFrom = attacker;
            this.fleeTicks = 240;
        }
    }

    // ------------------------------------------------------------------ подбор вещей

    /** Берёт посох путника с земли в руку (старую палку выбрасывает). */
    void equipStaffFrom(ItemEntity itemEntity) {
        ItemStack stack = itemEntity.getItem();
        if (!stack.is(WandererMod.WANDERER_STAFF.get())) return;
        this.take(itemEntity, 1);
        ItemStack old = this.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!old.isEmpty()) {
            this.spawnAtLocation(old.copy());
        }
        ItemStack one = stack.copy();
        one.setCount(1);
        this.setItemSlot(EquipmentSlot.MAINHAND, one);
        stack.shrink(1);
        if (stack.isEmpty()) {
            itemEntity.discard();
        } else {
            itemEntity.setItem(stack);
        }
        setVariant(2);
    }

    boolean wantsStaff(ItemStack stack) {
        if (!stack.is(WandererMod.WANDERER_STAFF.get())) return false;
        ItemStack hand = this.getItemBySlot(EquipmentSlot.MAINHAND);
        return hand.isEmpty() || hand.is(Items.STICK);
    }

    /** Нужна ли путнику эта броня: слот пуст или новая броня лучше. */
    boolean wantsArmor(ItemStack stack) {
        if (!(stack.getItem() instanceof ArmorItem armor)) return false;
        ItemStack cur = this.getItemBySlot(armor.getEquipmentSlot());
        if (cur.isEmpty()) return true;
        int curDefense = (cur.getItem() instanceof ArmorItem ca) ? ca.getDefense() : 0;
        return armor.getDefense() > curDefense;
    }

    /** Надевает подобранную броню (старую, худшую, снимает и выбрасывает). */
    void equipArmorFrom(ItemEntity itemEntity) {
        ItemStack stack = itemEntity.getItem();
        if (!(stack.getItem() instanceof ArmorItem armor) || !wantsArmor(stack)) return;
        EquipmentSlot slot = armor.getEquipmentSlot();
        this.take(itemEntity, 1);
        ItemStack old = this.getItemBySlot(slot);
        if (!old.isEmpty()) {
            this.spawnAtLocation(old.copy());
        }
        ItemStack one = stack.copy();
        one.setCount(1);
        this.setItemSlot(slot, one);
        stack.shrink(1);
        if (stack.isEmpty()) {
            itemEntity.discard();
        } else {
            itemEntity.setItem(stack);
        }
    }

    // ------------------------------------------------------------------ дроп

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        // вне зависимости от того, кто убил
        ItemStack held = this.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!held.isEmpty()) {
            float chance = 0.0F;
            if (held.is(Items.STICK)) {
                chance = 0.29F;      // палка: 29%
            } else if (held.is(WandererMod.WANDERER_STAFF.get())) {
                chance = 0.034F;     // посох путника: 3.4%
            }
            if (this.random.nextFloat() < chance) {
                this.spawnAtLocation(held.copy());
            }
        }
        // надетая броня выпадает целиком (путник её подобрал)
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack armor = this.getItemBySlot(slot);
            if (!armor.isEmpty()) {
                this.spawnAtLocation(armor.copy());
            }
        }
        float f = this.random.nextFloat();
        if (f < 0.11F) {
            this.spawnAtLocation(new ItemStack(Items.BREAD, 2));   // 11%: 2 хлеба
        } else if (f < 0.38F) {
            this.spawnAtLocation(new ItemStack(Items.BREAD, 1));   // 27%: 1 хлеб
        }
        if (this.random.nextFloat() < 0.05F) {                     // 5%: сухой паёк
            this.spawnAtLocation(new ItemStack(this.random.nextBoolean()
                    ? WandererMod.DRY_RATION.get() : WandererMod.DRY_RATION_STEAK.get()));
        }
    }

    // ------------------------------------------------------------------ кровать

    @Nullable
    private BlockPos findBed() {
        BlockPos origin = this.blockPosition();
        long now = this.level().getGameTime();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-24, -5, -24), origin.offset(24, 5, 24))) {
            if (!this.level().hasChunkAt(p)) continue;
            BlockState s = this.level().getBlockState(p);
            if (s.getBlock() instanceof BedBlock
                    && s.getValue(BedBlock.PART) == BedPart.HEAD
                    && !s.getValue(BedBlock.OCCUPIED)) {
                Long until = this.badBeds.get(p);
                if (until != null && until > now) continue;
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    /** Можно ли встать в этой клетке: она свободна, а под ней есть опора. */
    private boolean isStandable(BlockPos pos) {
        Level l = this.level();
        if (!l.hasChunkAt(pos)) return false;
        BlockState feet = l.getBlockState(pos);
        BlockState floor = l.getBlockState(pos.below());
        return feet.getCollisionShape(l, pos).isEmpty()
                && !floor.getCollisionShape(l, pos.below()).isEmpty();
    }

    /**
     * Путь до клетки, где можно встать рядом с кроватью (с четырёх сторон).
     * Если вокруг кровати нет свободной клетки (кровать "в стене"), пути нет и кровать не подходит.
     */
    @Nullable
    private Path pathToBed(BlockPos bed) {
        Path best = null;
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos stand = bed.relative(d);
            if (!isStandable(stand)) continue;
            Path p = this.getNavigation().createPath(stand, 0);
            if (p != null && p.canReach() && (best == null || p.getNodeCount() < best.getNodeCount())) {
                best = p;
            }
        }
        return best;
    }

    /** Для команды /wanderer sleepinfo: почему путник идёт или не идёт спать. */
    String sleepDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append("ночь=").append(isNightTime(this.level()));
        sb.append(", спит=").append(this.isSleeping());
        sb.append(", на земле=").append(this.onGround());
        BlockPos bed = findBed();
        if (bed == null) {
            sb.append(", кровать не найдена (радиус 24)");
        } else {
            sb.append(", кровать=").append(bed.toShortString());
            sb.append(", расстояние=").append(String.format("%.1f", Math.sqrt(
                    this.distanceToSqr(bed.getX() + 0.5D, bed.getY() + 0.5D, bed.getZ() + 0.5D))));
            int stands = 0;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (isStandable(bed.relative(d))) stands++;
            }
            sb.append(", свободных клеток рядом=").append(stands);
            Path p = pathToBed(bed);
            sb.append(", путь=").append(p == null ? "НЕТ" : "есть (" + p.getNodeCount() + " точек)");
            sb.append(", можно лечь=").append(canSleepOn(bed));
            Long until = this.badBeds.get(bed);
            sb.append(", в чёрном списке=").append(until != null && until > this.level().getGameTime());
        }
        sb.append(", цель=").append(this.getTarget() != null);
        sb.append(", убегает=").append(this.fleeFrom != null);
        sb.append(", приседает=").append(this.isCrouching());
        return sb.toString();
    }

    private boolean bedIsFree(BlockPos pos) {
        BlockState s = this.level().getBlockState(pos);
        return s.getBlock() instanceof BedBlock && !s.getValue(BedBlock.OCCUPIED);
    }

    /** Можно ли ложиться: рядом, на одной высоте и без стен между путником и кроватью. */
    private boolean canSleepOn(BlockPos bed) {
        double dx = this.getX() - (bed.getX() + 0.5D);
        double dz = this.getZ() - (bed.getZ() + 0.5D);
        if (dx * dx + dz * dz > 2.25D) return false;
        if (Math.abs(this.getY() - bed.getY()) > 1.0D) return false;
        Vec3 from = this.position().add(0.0D, 0.8D, 0.0D);
        Vec3 target = new Vec3(bed.getX() + 0.5D, bed.getY() + 0.3D, bed.getZ() + 0.5D);
        BlockHitResult hit = this.level().clip(
                new ClipContext(from, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (hit.getType() == HitResult.Type.MISS) return true;
        return this.level().getBlockState(hit.getBlockPos()).getBlock() instanceof BedBlock;
    }

    // ------------------------------------------------------------------ цели ИИ

    /** Ночью идёт к ближайшей кровати (к клетке рядом с ней) и спит до утра. Если дойти нельзя, просто бродит. */
    static class SleepInBedGoal extends Goal {
        private final WandererEntity mob;
        private BlockPos bed;
        private Path path;
        private int cooldown;
        private int giveUp;
        private int nearFail;
        private int noProgress;

        SleepInBedGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (!isNightTime(mob.level()) || mob.isSleeping() || mob.getTarget() != null || mob.fleeFrom != null) {
                return false;
            }
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            cooldown = 30 + mob.getRandom().nextInt(20);
            if (!mob.onGround()) return false;
            BlockPos found = mob.findBed();
            if (found == null) return false;
            if (mob.canSleepOn(found)) {   // уже стоит рядом
                bed = found;
                path = null;
                return true;
            }
            Path p = mob.pathToBed(found);
            if (p == null) {
                // рядом с кроватью негде встать или туда не дойти: не берём эту кровать
                mob.badBeds.put(found, mob.level().getGameTime() + 1200L);
                return false;
            }
            bed = found;
            path = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return bed != null && giveUp > 0 && isNightTime(mob.level()) && !mob.isSleeping()
                    && mob.getTarget() == null && mob.fleeFrom == null && mob.bedIsFree(bed);
        }

        @Override
        public void start() {
            giveUp = 800;
            nearFail = 0;
            noProgress = 0;
            if (path != null) {
                mob.getNavigation().moveTo(path, 1.0D);
            }
        }

        private void abandon(long ticks) {
            mob.badBeds.put(bed, mob.level().getGameTime() + ticks);
            giveUp = 0;
        }

        @Override
        public void tick() {
            giveUp--;
            if (mob.canSleepOn(bed)) {
                mob.startSleeping(bed);
                return;
            }
            // рядом, но лечь не получается (например, за стеной): не стоим бесконечно
            double dx = mob.getX() - (bed.getX() + 0.5D);
            double dz = mob.getZ() - (bed.getZ() + 0.5D);
            if (dx * dx + dz * dz < 6.25D) {
                if (++nearFail > 60) {
                    abandon(3600L);
                    return;
                }
            } else {
                nearFail = 0;
            }
            // не двигается слишком долго
            double mx = mob.getX() - mob.xo;
            double mz = mob.getZ() - mob.zo;
            if (mx * mx + mz * mz < 1.0E-4D) {
                if (++noProgress > 100) {
                    abandon(3600L);
                    return;
                }
            } else {
                noProgress = 0;
            }
            if (mob.getNavigation().isDone()) {
                Path p = mob.pathToBed(bed);
                if (p != null) {
                    mob.getNavigation().moveTo(p, 1.0D);
                } else {
                    abandon(1200L);
                }
            }
        }

        @Override
        public void stop() {
            if (!mob.isSleeping()) {
                mob.getNavigation().stop();
            }
            bed = null;
            path = null;
        }
    }

    /** Бой: идёт к цели, смотрит на неё и бьёт (замах руки как у игрока). Не зависает на расстоянии. */
    static class FightGoal extends Goal {
        private final WandererEntity mob;
        private int attackCooldown;
        private int repathTimer;

        FightGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive() && mob.fleeFrom == null && !mob.isSleeping();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            mob.setAggressive(true);
            repathTimer = 0;
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null) return;
            mob.getLookControl().setLookAt(t, 30.0F, 30.0F);
            double d2 = mob.distanceToSqr(t.getX(), t.getY(), t.getZ());
            if (--repathTimer <= 0) {
                repathTimer = 4 + mob.getRandom().nextInt(7);
                if (d2 > 2.0D) {
                    // если пути нет, идём к цели напрямую, а не стоим и смотрим
                    if (!mob.getNavigation().moveTo(t, 1.15D)) {
                        mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.15D);
                        mob.directMoveTicks = 6;
                    }
                }
            }
            if (attackCooldown > 0) attackCooldown--;
            if (d2 <= 3.2D && attackCooldown <= 0 && mob.hasLineOfSight(t)) {
                attackCooldown = 20;
                mob.swing(InteractionHand.MAIN_HAND);
                mob.triggerAttackAnim();
                mob.doHurtTarget(t);
            }
        }

        @Override
        public void stop() {
            mob.setAggressive(false);
            mob.getNavigation().stop();
        }
    }

    /** Общая цель: подойти к предмету на земле в радиусе 15 блоков и подобрать. */
    abstract static class PickUpGoal extends Goal {
        protected final WandererEntity mob;
        private ItemEntity target;
        private int cooldown;

        PickUpGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        abstract boolean wants(ItemStack stack);

        abstract void pickUp(ItemEntity item);

        @Override
        public boolean canUse() {
            if (mob.isSleeping() || mob.getTarget() != null || mob.fleeFrom != null) return false;
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            cooldown = 20 + mob.getRandom().nextInt(20);
            long now = mob.level().getGameTime();
            List<ItemEntity> list = mob.level().getEntitiesOfClass(ItemEntity.class,
                    mob.getBoundingBox().inflate(15.0D, 5.0D, 15.0D),
                    e -> e.isAlive() && wants(e.getItem())
                            && mob.badItems.getOrDefault(e.getUUID(), 0L) <= now);
            if (list.isEmpty()) return false;
            list.sort(Comparator.comparingDouble(e -> mob.distanceToSqr(e)));
            ItemEntity candidate = list.get(0);
            Path p = mob.getNavigation().createPath(candidate, 0);
            if (p == null) return false;
            if (!p.canReach()) {
                // предмет за стеной или недостижим: не стоим у стены, пропускаем его на минуту
                mob.badItems.put(candidate.getUUID(), now + 1200L);
                return false;
            }
            target = candidate;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && !mob.isSleeping()
                    && mob.getTarget() == null && mob.fleeFrom == null
                    && mob.distanceToSqr(target) < 20.0D * 20.0D && wants(target.getItem());
        }

        @Override
        public void start() {
            mob.getNavigation().moveTo(target, 1.0D);
        }

        @Override
        public void tick() {
            if (target == null) return;
            if (mob.distanceToSqr(target) < 2.25D) {
                pickUp(target);
                target = null;
            } else if (mob.getNavigation().isDone()) {
                mob.getNavigation().moveTo(target, 1.0D);
            }
        }

        @Override
        public void stop() {
            target = null;
            mob.getNavigation().stop();
        }
    }

    static class PickUpStaffGoal extends PickUpGoal {
        PickUpStaffGoal(WandererEntity mob) {
            super(mob);
        }

        @Override
        boolean wants(ItemStack stack) {
            return mob.wantsStaff(stack);
        }

        @Override
        void pickUp(ItemEntity item) {
            mob.equipStaffFrom(item);
        }
    }

    static class PickUpArmorGoal extends PickUpGoal {
        PickUpArmorGoal(WandererEntity mob) {
            super(mob);
        }

        @Override
        boolean wants(ItemStack stack) {
            return mob.wantsArmor(stack);
        }

        @Override
        void pickUp(ItemEntity item) {
            mob.equipArmorFrom(item);
        }
    }

    /** Убегает от того, кто его ударил. */
    static class FleeAttackerGoal extends Goal {
        private final WandererEntity mob;

        FleeAttackerGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.fleeFrom != null && mob.fleeFrom.isAlive() && mob.fleeTicks > 0;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            runAway();
        }

        @Override
        public void tick() {
            if (mob.getNavigation().isDone()) {
                runAway();
            }
        }

        private void runAway() {
            if (mob.fleeFrom == null) return;
            Vec3 away = DefaultRandomPos.getPosAway(mob, 16, 7, mob.fleeFrom.position());
            if (away != null) {
                mob.getNavigation().moveTo(away.x, away.y, away.z, 1.45D);
            }
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }
}
