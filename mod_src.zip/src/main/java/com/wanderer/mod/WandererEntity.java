package com.wanderer.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.UUID;

/**
 * Путник. При появлении: 5% посох путника, 11% обычная палка, 84% без оружия.
 * Если его ударили: 25% драться до конца, 75% убегать. Ночью идёт спать на ближайшую кровать.
 */
public class WandererEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(WandererEntity.class, EntityDataSerializers.INT); // 0 пусто, 1 палка, 2 посох
    private static final EntityDataAccessor<Integer> SKIN =
            SynchedEntityData.defineId(WandererEntity.class, EntityDataSerializers.INT);

    /** От кого убегаем и сколько ещё тиков. */
    private LivingEntity fleeFrom;
    private int fleeTicks;

    /** Решение "драться или убегать" запоминаем на 30 секунд для каждого обидчика. */
    private UUID decidedAttacker;
    private long decidedTime;
    private boolean decidedFight;

    public WandererEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 24.0D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SleepInBedGoal(this));
        this.goalSelector.addGoal(1, new FleeAttackerGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
        this.entityData.define(SKIN, 0);
    }

    public int getVariant() {
        return this.entityData.get(VARIANT);
    }

    public void setVariant(int variant) {
        this.entityData.set(VARIANT, variant);
    }

    public int getSkin() {
        return this.entityData.get(SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(SKIN, skin);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        tag.putInt("Skin", getSkin());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        setSkin(tag.getInt("Skin"));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
        setSkin(this.random.nextInt(2)); // 50% / 50% один из двух скинов

        float r = this.random.nextFloat();
        if (r < 0.05F) {                       // 5% посох путника
            setVariant(2);
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(WandererMod.WANDERER_STAFF.get()));
        } else if (r < 0.16F) {                // 11% обычная палка
            setVariant(1);
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STICK));
        } else {                               // 84% без оружия
            setVariant(0);
        }
        return data;
    }

    // ------------------------------------------------------------------ сон / поведение

    private static boolean isNightTime(Level level) {
        return level.getDayTime() % 24000L >= 13000L;
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.isSleeping();
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            serverTick();
        }
    }

    private void serverTick() {
        // утром просыпаемся
        if (this.isSleeping() && !isNightTime(this.level())) {
            this.stopSleeping();
        }
        // таймер бегства
        if (this.fleeTicks > 0) {
            this.fleeTicks--;
            if (this.fleeTicks == 0 || this.fleeFrom == null || !this.fleeFrom.isAlive()) {
                this.fleeFrom = null;
                this.fleeTicks = 0;
            }
        }
        // бой заканчивается, если цель умерла или убежала далеко
        LivingEntity t = this.getTarget();
        if (t != null && (!t.isAlive() || this.distanceToSqr(t) > 32.0D * 32.0D
                || (t instanceof Player p && p.isSpectator()))) {
            this.setTarget(null);
        }
        // враждебные мобы рядом нападают на путника
        if (this.tickCount % 20 == 0) {
            for (Monster m : this.level().getEntitiesOfClass(Monster.class,
                    this.getBoundingBox().inflate(12.0D, 4.0D, 12.0D))) {
                if (m instanceof NeutralMob) continue;
                if (m.getTarget() == null && m.hasLineOfSight(this)) {
                    m.setTarget(this);
                }
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && !this.level().isClientSide) {
            if (this.isSleeping()) {
                this.stopSleeping();
            }
            Entity attacker = source.getEntity();
            if (attacker instanceof LivingEntity le && le != this && !(le instanceof WandererEntity)) {
                reactToAttacker(le);
            }
        }
        return result;
    }

    /** 25% драться до конца, 75% убегать. Решение держится 30 секунд для одного и того же обидчика. */
    private void reactToAttacker(LivingEntity attacker) {
        long now = this.level().getGameTime();
        UUID id = attacker.getUUID();
        if (!(id.equals(this.decidedAttacker) && now - this.decidedTime < 600L)) {
            this.decidedAttacker = id;
            this.decidedFight = this.random.nextFloat() < 0.25F;
        }
        this.decidedTime = now;
        if (this.decidedFight) {
            this.fleeFrom = null;
            this.fleeTicks = 0;
            this.setTarget(attacker);
        } else {
            this.setTarget(null);
            this.fleeFrom = attacker;
            this.fleeTicks = 240;
        }
    }

    // ------------------------------------------------------------------ дроп

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        // вне зависимости от того, кто убил
        ItemStack held = this.getItemBySlot(EquipmentSlot.MAINHAND);
        if (!held.isEmpty()) {
            float chance = 0.0F;
            if (held.is(Items.STICK)) {
                chance = 0.29F;      // палка: 29%
            } else if (held.is(WandererMod.WANDERER_STAFF.get())) {
                chance = 0.034F;     // посох путника: 3.4%
            }
            if (this.random.nextFloat() < chance) {
                this.spawnAtLocation(held.copy());
            }
        }
        float f = this.random.nextFloat();
        if (f < 0.11F) {
            this.spawnAtLocation(new ItemStack(Items.BREAD, 2));   // 11%: 2 хлеба
        } else if (f < 0.38F) {
            this.spawnAtLocation(new ItemStack(Items.BREAD, 1));   // 27%: 1 хлеб
        }
        if (this.random.nextFloat() < 0.05F) {                     // 5%: сухой паёк
            this.spawnAtLocation(new ItemStack(this.random.nextBoolean()
                    ? WandererMod.DRY_RATION.get() : WandererMod.DRY_RATION_STEAK.get()));
        }
    }

    // ------------------------------------------------------------------ поиск кровати

    @Nullable
    private BlockPos findBed() {
        BlockPos origin = this.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-20, -5, -20), origin.offset(20, 5, 20))) {
            if (!this.level().hasChunkAt(p)) continue;
            BlockState s = this.level().getBlockState(p);
            if (s.getBlock() instanceof BedBlock
                    && s.getValue(BedBlock.PART) == BedPart.HEAD
                    && !s.getValue(BedBlock.OCCUPIED)) {
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    private boolean bedIsFree(BlockPos pos) {
        BlockState s = this.level().getBlockState(pos);
        return s.getBlock() instanceof BedBlock && !s.getValue(BedBlock.OCCUPIED);
    }

    // ------------------------------------------------------------------ цели ИИ

    /** Ночью идёт к ближайшей кровати и спит до утра. Если кровати нет, просто продолжает бродить. */
    static class SleepInBedGoal extends Goal {
        private final WandererEntity mob;
        private BlockPos bed;
        private int cooldown;
        private int giveUp;

        SleepInBedGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            if (!isNightTime(mob.level()) || mob.isSleeping() || mob.getTarget() != null || mob.fleeFrom != null) {
                return false;
            }
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            cooldown = 60 + mob.getRandom().nextInt(40);
            bed = mob.findBed();
            return bed != null;
        }

        @Override
        public boolean canContinueToUse() {
            return bed != null && giveUp > 0 && isNightTime(mob.level()) && !mob.isSleeping()
                    && mob.getTarget() == null && mob.fleeFrom == null && mob.bedIsFree(bed);
        }

        @Override
        public void start() {
            giveUp = 600;
            mob.getNavigation().moveTo(bed.getX() + 0.5D, bed.getY(), bed.getZ() + 0.5D, 1.0D);
        }

        @Override
        public void tick() {
            giveUp--;
            double d = mob.distanceToSqr(bed.getX() + 0.5D, bed.getY() + 0.5D, bed.getZ() + 0.5D);
            if (d < 2.5D) {
                mob.startSleeping(bed);
            } else if (mob.getNavigation().isDone()) {
                mob.getNavigation().moveTo(bed.getX() + 0.5D, bed.getY(), bed.getZ() + 0.5D, 1.0D);
            }
        }

        @Override
        public void stop() {
            if (!mob.isSleeping()) {
                mob.getNavigation().stop();
            }
            bed = null;
        }
    }

    /** Убегает от того, кто его ударил (в 75% случаев). */
    static class FleeAttackerGoal extends Goal {
        private final WandererEntity mob;

        FleeAttackerGoal(WandererEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.fleeFrom != null && mob.fleeFrom.isAlive() && mob.fleeTicks > 0;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void start() {
            runAway();
        }

        @Override
        public void tick() {
            if (mob.getNavigation().isDone()) {
                runAway();
            }
        }

        private void runAway() {
            if (mob.fleeFrom == null) return;
            Vec3 away = DefaultRandomPos.getPosAway(mob, 16, 7, mob.fleeFrom.position());
            if (away != null) {
                mob.getNavigation().moveTo(away.x, away.y, away.z, 1.45D);
            }
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }
}
